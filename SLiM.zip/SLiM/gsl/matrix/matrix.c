#include "config.h"
#include "gsl_errno.h"
#include "gsl_vector.h"

/* Compile all the inline matrix functions */

#define COMPILE_INLINE_STATIC
#include "build.h"
#include "gsl_matrix.h"

